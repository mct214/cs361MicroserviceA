const express = require("express")
const app = express();
const PORT = 3000;

app.get("/download/:filename", (req, res) => {

    const filePath = __dirname + "/public/photos/" + req.params.filename;
    res.download(
        filePath, 
        "downloaded-image.png"
    )
})

app.listen( PORT, () => console.log("Server listening to port " + PORT))